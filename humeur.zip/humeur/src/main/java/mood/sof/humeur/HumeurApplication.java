package mood.sof.humeur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HumeurApplication {

    public static void main(String[] args) {
        SpringApplication.run(HumeurApplication.class, args);
    }
}